#include "led.h"

void LED_Init() {
    // 启用 GPIOA 和 GPIOC 时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_InitTypeDef GPIO_InitStruct;   
    // 初始化 GPIOA 引脚 0，1，2，3，4，5，6，7
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_All;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    // 初始化 GPIOC 引脚
    GPIO_Init(GPIOC, &GPIO_InitStruct);
}

void LEDdisplay() {
    while (1) {
        GPIO_Write(GPIOC, 0xfe);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xfd);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xfb);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xf7);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xef);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xdf);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0xbf);
        delay_ms(1000);
        GPIO_Write(GPIOC, 0x7f);
        delay_ms(1000);
    }
}