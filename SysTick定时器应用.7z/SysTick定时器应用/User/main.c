#include "public.h"
#include "stm32f10x.h"
#include "led.h"
#include "systick.h"
#include "beep.h"

int main() {
    u16 n;
    LED_Init();
    SYSTICK_Init(72);
    BEEP_Init();
    /*分别对应叮咚，音调，歌曲1，歌曲2，歌曲3 。需要哪个就把注释取消*/
    while (1) {
        //dingdong();
        //play_music();
        //play_music1();   
        play_music2();
        //play_music3();
    }
}