#include "SysTick.h"
u32 fac_us, fac_ms;

void SYSTICK_Init(u8 SYSCLK){
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
    fac_us = SYSCLK / 8;
    fac_ms = fac_us * 1000;
}

void delay_us(u32 nus){
    u32 temp;
    SysTick->LOAD = nus * fac_us;
    SysTick->CTRL = 0x01;
    SysTick->VAL = 0x00;
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));
    SysTick->CTRL = 0x00;
    SysTick->VAL = 0x00;
}

void delay_ms(u32 nms){
    u32 temp;
    SysTick->LOAD = nms * fac_ms;
    SysTick->CTRL = 0x01;
    SysTick->VAL = 0x00;
    do {
        temp = SysTick->CTRL;
    } while ((temp & 0x01) && !(temp & (1 << 16)));
    SysTick->CTRL = 0x00;
    SysTick->VAL = 0x00;
}