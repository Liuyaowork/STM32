#ifndef _SYSTICK_H
#define _SYSTICK_H

#include "stm32f10x.h"

// 在此处添加 SysTick 定时器相关的函数声明
void SysTick_Init(void);
void SysTick_Handler(void);

#endif
