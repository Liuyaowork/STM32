#include "dz.h"
#include "systick.h"

u8 ROW [] = {0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
u8 love [] = {0xff,0x99,0x66,0x7e,0x7e,0xbd,0xdb,0xe7};
u8 love1 [] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
u8 Display_0 [] = {0xe7,0xdb,0xdb,0xdb,0xdb,0xdb,0xdb,0xe7};
u8 Display_1 [] = {0xe7,0xc7,0xe7,0xe7,0xe7,0xe7,0xc3,0xc3};
u8 Display_2 [] = {0xe1,0xc1,0xc9,0xf3,0xe7,0xcf,0x81,0x81};
u8 Display_3 [] = {0xff,0xe3,0xdd,0xfd,0xe1,0xfd,0xdd,0xe3};
u8 Display_4 [] = {0xf1,0xe1,0xc9,0x99,0x00,0x00,0xf9,0xf9};
u8 Display_5 [] = {0xc1,0xc1,0xcf,0xc3,0xc1,0xf9,0xc1,0xe3};
u8 Display_6 [] = {0xc3,0xbd,0xbf,0x83,0xbd,0xbd,0xbd,0xc3};
u8 Display_7 [] = {0x83,0x83,0xf3,0xf3,0xf3,0xf3,0xf3,0xf3};
u8 Display_8 [] = {0xff,0xe3,0xdd,0xdd,0xc1,0xdd,0xdd,0xe3};
u8 Display_9 [] = {0xe3,0xdd,0xdd,0xe1,0xfd,0xfd,0xfd,0xfd};
u8 kunkun1 [] = {0xf7,0xef,0xd7,0xdb,0xe7,0xdb,0xbd,0xbd};
u8 kunkun2 [] = {0xff,0xfd,0xf3,0xeb,0xe7,0xdb,0xbd,0xbd};
u8 kunkun3 [] = {0xfd,0xf3,0xeb,0xe7,0xe7,0xdb,0xbd,0xbd};
u8 kunkun4 [] = {0xff,0xf7,0xef,0xd7,0xe7,0xdb,0xbd,0xbd};
u8 kunkun5 [] = {0xf7,0xef,0xc7,0xcb,0xe7,0xdb,0xbd,0xbd};
u16 a, b, num, t;

void DZ_Init(){
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);

    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_All;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void senddata595(u8 data){
    u8 i;
    for(i = 0; i < 8; i++){
        if((data & 0x80) == 0x80) {ds_1;}
        else  {ds_0;}
        sh_0;
        sh_1;
        data <<= 1;
    }
    st_0;
    st_1;
}

void DZ_love(){
    u8 n;
    for(n = 0; n < 8; n++){
        senddata595(ROW[n]);
        GPIO_Write(GPIOA, love[n]);
        delay_ms(1);
        senddata595(0x00);
        GPIO_Write(GPIOA, 0xff);
        delay_ms(1);
    }
}

void DZ_love1() {
    u8 n;
    for (n = 0; n < 8; n++) {
        senddata595(ROW[n]);
        GPIO_Write(GPIOA, love1[n]);
        delay_ms(1);
        senddata595(0x00);
        GPIO_Write(GPIOA, 0xff);
        delay_ms(1);
    }
}

void DZ_displayPattern(u8 *pattern){
    u8 n;
    for(n = 0; n < 8; n++){
        senddata595(ROW[n]);
        GPIO_Write(GPIOA, pattern[n]);
        delay_ms(1);
        senddata595(0x00);
        GPIO_Write(GPIOA, 0xff);
        delay_ms(1);
    }
}

void DisplayPattern_0(){
    DZ_displayPattern(Display_0);
}

void DisplayPattern_1(){
    DZ_displayPattern(Display_1);
}

void DisplayPattern_2(){
    DZ_displayPattern(Display_2);
}

void DisplayPattern_3(){
    DZ_displayPattern(Display_3);
}

void DisplayPattern_4(){
    DZ_displayPattern(Display_4);
}

void DisplayPattern_5(){
    DZ_displayPattern(Display_5);
}

void DisplayPattern_6(){
    DZ_displayPattern(Display_6);
}

void DisplayPattern_7(){
    DZ_displayPattern(Display_7);
}

void DisplayPattern_8(){
    DZ_displayPattern(Display_8);
}

void DisplayPattern_9(){
    DZ_displayPattern(Display_9);
}

void DZ_kunkun1(){
    DZ_displayPattern(kunkun1);
}

void DZ_kunkun2(){
    DZ_displayPattern(kunkun2);
}

void DZ_kunkun3(){
    DZ_displayPattern(kunkun3);
}

void DZ_kunkun4(){
    DZ_displayPattern(kunkun4);
}

void DZ_kunkun5(){
    DZ_displayPattern(kunkun5);
}
