#ifndef _DZ_H
#define _DZ_H
#include "stm32f10x.h"

#define sh_0 GPIO_ResetBits(GPIOB, GPIO_Pin_3);
#define sh_1 GPIO_SetBits(GPIOB, GPIO_Pin_3);

#define ds_0 GPIO_ResetBits(GPIOB, GPIO_Pin_4);
#define ds_1 GPIO_SetBits(GPIOB, GPIO_Pin_4);

#define st_0 GPIO_ResetBits(GPIOB, GPIO_Pin_5);
#define st_1 GPIO_SetBits(GPIOB, GPIO_Pin_5);

void DZ_Init();
void senddata595(u8 data);
void DZ_love();
void DZ_love1();
void DZ_displayPattern(u8 *pattern);
void DisplayPattern_0();
void DisplayPattern_1();
void DisplayPattern_2();
void DisplayPattern_3();
void DisplayPattern_4();
void DisplayPattern_5();
void DisplayPattern_6();
void DisplayPattern_7();
void DisplayPattern_8();
void DisplayPattern_9();
void DZ_kunkun1();
void DZ_kunkun2();
void DZ_kunkun3();
void DZ_kunkun4();
void DZ_kunkun5();

#endif