#ifndef _BEEP_H
#define _BEEP_H
#include "stm32f10x.h"
#include "systick.h"

void BEEP_Init(void);
void dingdong();
void play_music();
void play_music1();
void play_music2();
void play_music3();

#endif