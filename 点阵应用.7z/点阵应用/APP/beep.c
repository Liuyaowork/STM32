#include "beep.h"
#include "systick.h"

u16 di[] = {0, 262, 294, 330, 349, 392, 440, 494};
u16 zhong[] = {0, 523, 587, 659, 698, 784, 880, 988};
u16 gao[] = {0, 1047, 1175, 1319, 1397, 1568, 1760, 1976};

/*歌谱怎么改：列如123（3头上带点），将歌谱的每1个数拆成3个数，数字上不带点则最后一个数为2表示中音，数字上带点为3表示高音结果为（1，4，2（中音），   2，4，2（中音），   3，4，3（高音））*/
/*歌曲1修改大括号里的数值，小红书搜数字简谱（尽量找简单的只有数字和数字头上或者下面的点）。*/
u16 music1[] = {
    3,4,2,  5,4,2,  5,4,2,  6,4,2,  5,4,2,  3,4,2,  1,4,2, 
    1,4,2,  2,4,2,  3,4,2,  3,4,2,  2,4,2,  1,4,2,  2,4,2,
    3,4,2,  5,4,2,  5,4,2,  6,4,2,  5,4,2,  3,4,2,  1,4,2,
    1,4,2,  2,4,2,  3,4,2,  3,4,2,  2,4,2,  2,4,2,  1,4,2,
    4,4,2,  4,4,2,  4,4,2,  6,4,2,  5,4,2,  5,4,2,  2,4,2,
    3,4,2,  5,4,2,  5,4,2,  6,4,2,  5,4,2,  3,4,2,  1,4,2,
    1,4,2,  2,4,2,  3,4,2,  3,4,2,  2,4,2,  2,4,2,  1,4,2
};
/*歌曲2修改大括号里的数值，小红书搜数字简谱（尽量找简单的只有数字和数字头上或者下面的点）*/
u16 music2[] = {
    1,4,3,  2,4,3,  3,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  2,4,3,
    3,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  3,4,3,
    2,4,3,  1,4,3,  6,4,2,  1,4,3,
    1,4,3,  2,4,3,  1,4,3,  6,4,3,
    1,4,3,  3,4,3,  4,4,3,  3,4,3,  3,4,3,  2,4,3,  3,4,3,  2,4,3,
    1,4,3,  2,4,3,  3,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  2,4,3,
    3,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  6,4,3,  5,4,3,  3,4,3,
    2,4,3,  1,4,3,  6,4,2,  3,4,3,
    2,4,3,  1,4,3,  6,4,2,  1,4,3,  1,4,3,
    6,4,2,  3,4,3,  2,4,3,  1,4,3,  6,4,2,
    3,4,3,  2,4,3,  1,4,3,  6,4,2,  1,4,3,  1,4,3
};
/*歌曲3修改大括号里的数值，小红书搜数字简谱（尽量找简单的只有数字和数字头上或者下面的点）*/
u16 music3[] = {
    5,4,2,  5,4,2,  3,4,2,  2,4,2,  3,4,2,  6,4,3,
    2,4,2,  3,4,2,  5,4,2,  3,4,2,  2,4,2,
    5,4,2,  5,4,2,  3,4,2,  2,4,2,  3,4,2,  6,4,3,
    2,4,2,  3,4,2,  5,4,2,  2,4,2,  1,4,2,
    1,4,2,  2,4,2,  3,4,2,  5,4,2,  6,4,2,  5,4,2,  3,4,2,  3,4,2,  2,4,2,  2,4,2,
    1,4,2,  2,4,2,  1,4,2,  2,4,2,  1,4,2,  2,4,2,  3,4,2,  5,4,2,  3,4,2
};

void BEEP_Init() {
    // 启用 GPIOB 时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitTypeDef GPIO_InitStruct;
    // 初始化 GPIOB 引脚 0
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);
}
/*dingdong不要修改*/
void dingdong() {
    u16 n, t, f;
    f = 500; // 设置频率为500Hz
    t = 1000000 / f; // 计算周期
    for (n = 0; n < 300; n++) { // 叮声
        GPIO_ResetBits(GPIOB, GPIO_Pin_0);
        delay_us(t / 2);
        GPIO_SetBits(GPIOB, GPIO_Pin_0);
        delay_us(t / 2);
    }
    delay_ms(100); // 间隔
    f = 700; // 设置频率为700Hz
    t = 1000000 / f; // 计算周期
    for (n = 0; n < 300; n++) { // 咚声
        GPIO_ResetBits(GPIOB, GPIO_Pin_0);
        delay_us(t / 2);
        GPIO_SetBits(GPIOB, GPIO_Pin_0);
        delay_us(t / 2);
    }
    delay_ms(100);
}
/*音调不要修改*/
void play_music() {
    u16 n, t, f, i;
    for (i = 1; i < 8; i++) {
        f = di[i];
        t = 1000000 / f;
        for (n = 0; n < 300; n++) {
            GPIO_ResetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
            GPIO_SetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
        }
        delay_ms(100);
    }
    for (i = 1; i < 8; i++) {
        f = zhong[i];
        t = 1000000 / f;
        for (n = 0; n < 300; n++) {
            GPIO_ResetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
            GPIO_SetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
        }
        delay_ms(100);
    }
    for (i = 1; i < 8; i++) {
        f = gao[i];
        t = 1000000 / f;
        for (n = 0; n < 300; n++) {
            GPIO_ResetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
            GPIO_SetBits(GPIOB, GPIO_Pin_0);
            delay_us(t / 2);
        }
        delay_ms(100);
    }
}

void play_music1() {
    u16 tone, jiepaima, dizhonggao, n, t, i;
    for (i = 0; i < sizeof(music1) / sizeof(music1[0]); i++) {
        tone = music1[i];
        jiepaima = music1[++i];
        dizhonggao = music1[++i];/*(jiepai*5)指的是歌曲的节拍，歌曲慢就把后面的数字改小，反之改大。按照实际仿真结果来修改*/
        for (n = 0; n < jiepaima * 4; n++) {
            if (dizhonggao == 1) {
                t = 10000000 / di[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 2) {
                t = 10000000 / zhong[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 3) {
                t = 10000000 / gao[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 0) {
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
        }
    }
    delay_ms(100);
}

void play_music2() {
    u16 tone, jiepaima, dizhonggao, n, t, i;
    for (i = 0; i < sizeof(music2) / sizeof(music2[0]); i++) {
        tone =music2[i];
        jiepaima = music2[++i];
        dizhonggao = music2[++i];/*(jiepai*5)指的是歌曲的节拍，歌曲慢就把后面的数字改小，反之改大。按照实际仿真结果来修改*/
        for (n = 0; n < jiepaima * 12; n++) {
            if (dizhonggao == 1) {
                t = 10000000 / di[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 2) {
                t = 10000000 / zhong[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 3) {
                t = 10000000 / gao[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 0) {
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
        }
    }
    delay_ms(100);
}

void play_music3() {
    u16 tone, jiepaima, dizhonggao, n, t, i;
    for (i = 0; i < sizeof(music3) / sizeof(music3[0]); i++) {
        tone = music3[i];
        jiepaima = music3[++i];
        dizhonggao = music3[++i];/*(jiepai*5)指的是歌曲的节拍，歌曲慢就把后面的数字改小，反之改大。按照实际仿真结果来修改*/
        for (n = 0; n < jiepaima * 5; n++) {
            if (dizhonggao == 1) {
                t = 10000000 / di[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 2) {
                t = 10000000 / zhong[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 3) {
                t = 10000000 / gao[tone];
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
                GPIO_SetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
            if (dizhonggao == 0) {
                GPIO_ResetBits(GPIOB, GPIO_Pin_0);
                delay_us(t / 2);
            }
        }
    }
    delay_ms(100);
}