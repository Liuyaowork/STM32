#include "public.h"
#include "stm32f10x.h"
#include "led.h"
#include "systick.h"
#include "beep.h"
#include "dz.h"

int main() {
    u16 n, t;
    LED_Init();
    SYSTICK_Init(72);
    BEEP_Init();
    DZ_Init();
    while (1) {
        // 静态显示
        //DZ_love();

        // 动态显示
        /*
        for (t = 0; t < 10; t++) {
            DZ_love();
        }
        for (t = 0; t < 5; t++) {
            DZ_love1();
        }*/

        for (t = 0; t < 50; t++) {
            DisplayPattern_0();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_1();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_2();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_3();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_4();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_5();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_6();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_7();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_8();
        }
        for(t = 0; t < 50; t++){
            DisplayPattern_9();
        }
/*
        for(t = 0; t < 5; t++)
        DZ_kunkun1();
        for(t = 0; t < 5; t++){
            DZ_kunkun2();
        }
        for(t = 0; t < 5; t++){
            DZ_kunkun3();
        }
        for(t = 0; t < 5; t++){
            DZ_kunkun4();
        }
        for(t = 0; t < 5; t++){
            DZ_kunkun5();
        }*/
    }
}