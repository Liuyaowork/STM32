#include"public.h"
#include"stm32f10x.h"
#include"led.h"

void delay(u32 x)
{
    u32 i,j;
    for(i=x;i>0;i--)
    
        for(j=5000;j>0;j--);
    
}

int main()
{
    LED_Init();
    while(1)
    {
        // 向下流水
        for(int i = 0; i < 8; i++) {
            GPIO_SetBits(GPIOA, 1 << i);
            delay(10);
            GPIO_ResetBits(GPIOA, 1 << i);
        }

        // 向上流水
        for(int i = 7; i >= 0; i--) {
            GPIO_SetBits(GPIOA, 1 << i);
            delay(10);
            GPIO_ResetBits(GPIOA, 1 << i);
        }

        // 双向流水
        for(int i = 0; i < 4; i++) {
            GPIO_SetBits(GPIOA, (1 << i) | (1 << (7 - i)));
            delay(10);
            GPIO_ResetBits(GPIOA, (1 << i) | (1 << (7 - i)));
        }

        // 交叉闪烁3次
        for(int i = 0; i < 3; i++) {
            GPIO_ResetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_4 | GPIO_Pin_6);
            GPIO_SetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_7);
            delay(10);
            GPIO_ResetBits(GPIOA, GPIO_Pin_1 | GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_7);
            GPIO_SetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_4 | GPIO_Pin_6);
            delay(10);
        }

        // 全亮全灭2次
        for(int i = 0; i < 2; i++) {
            GPIO_SetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            delay(10);
            GPIO_ResetBits(GPIOA, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
            delay(10);
        }
    }
}